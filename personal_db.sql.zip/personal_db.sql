-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Dec 14, 2015 at 09:50 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `personal_db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `admission`
-- 

CREATE TABLE `admission` (
  `id` int(45) NOT NULL auto_increment,
  `firstname` varchar(77) NOT NULL,
  `lastname` varchar(13) NOT NULL,
  `studentid` int(19) NOT NULL,
  `lastfourdigit` int(20) NOT NULL,
  `securitynu` int(45) NOT NULL,
  `address` varchar(30) NOT NULL,
  `streetaddress` varchar(17) NOT NULL,
  `streetdline` varchar(18) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(67) NOT NULL,
  `zipcode` int(98) NOT NULL,
  `email` varchar(89) NOT NULL,
  `areyouprniaccst` varchar(75) NOT NULL,
  `areyoucurrentlyattending` varchar(65) NOT NULL,
  `areyouseekingadegreeatniacc` varchar(45) NOT NULL,
  `whattermareyouregisteringfor` varchar(35) NOT NULL,
  `course1title` varchar(23) NOT NULL,
  `course1titlename` varchar(23) NOT NULL,
  `course2` varchar(24) NOT NULL,
  `youhaveadditionalinformation` varchar(23) NOT NULL,
  `termstart` varchar(56) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `admission`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `apply`
-- 

CREATE TABLE `apply` (
  `id` int(11) NOT NULL auto_increment,
  `applied` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `oname` varchar(255) NOT NULL,
  `register` varchar(20) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `nationalty` varchar(50) NOT NULL,
  `marks` varchar(255) NOT NULL,
  `adress` varchar(255) NOT NULL,
  `box` varchar(15) NOT NULL,
  `phone` int(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `register` (`register`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `apply`
-- 

INSERT INTO `apply` (`id`, `applied`, `sname`, `oname`, `register`, `dob`, `age`, `religion`, `gender`, `nationalty`, `marks`, `adress`, `box`, `phone`, `email`, `image`) VALUES 
(4, 'ceaser', 'Elias', 'Ceaser Birori Simon', '', '1989', 24, 'catholic', 'male', 'S.S', 'phical', '0989897878', '909', 792215744, 'cea@yahoo.com', 'DSC_1199.jpg'),
(5, 'ceaser', 'Elias', 'Ceaser Birori Simon', '202479', '1989', 25, 'Christian', 'male', 'ugamnda', 'physical', '0989897878', '98888', 9989989, 'ceaser99@gmail.com', 'DSC_1198.jpg'),
(6, 'sdsd', 'fdf', 'ddds', '788', '8989', 56, 'fdfd', '', '', 'gffgfg', '0989897878', '', 0, 'fhfghdf@hdjhjfj.com', '1445689216857.jpg'),
(7, 'Jackson', 'Elias', 'Kumba', '899999', '1992', 21, 'Christian', 'male', 'S.S', 'physical', '98989', '124', 773839776, 'juba24@gmail.com', 'DSC_1198.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `contact`
-- 

CREATE TABLE `contact` (
  `id` int(56) NOT NULL auto_increment,
  `name` varchar(87) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` int(11) NOT NULL,
  `subject` varchar(38) NOT NULL,
  `message` varchar(87) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `message` (`message`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `contact`
-- 

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `subject`, `message`) VALUES 
(1, 'cc', 'ceaser@gmail.com', 792215744, 'hddd', 'hgdfdgfdjghfdgfjhg'),
(2, 'Scovia Oleyo', 'scovia@yahoo.com', 77737333, 'Accounting', 'thank you for very much'),
(3, 'ceaser', 'cea@yahoo.com', 883833, 'BAIT', 'wow wonderful job'),
(4, 'Birori', 'ceaser@gmail.com', 77775645, 'E-commerce', 'my most ferocity subject'),
(5, 'Agustino AKASIA', 'akassiaa2@gmail.com', 773839776, 'Application', 'Dear am applying for admission'),
(6, 'rer', 'ceaser@gmail.com', 792215744, 'computer', 'erfetrt'),
(7, 'cgdgsgd', 'rery@yh.com', 754787127, 'computer', 'yturtyrutyurtu'),
(8, '', '', 0, '', ''),
(9, 'cgdgsgd', 'ceaser@gmail.com', 77737333, '0999977', 'ereyreyrt'),
(10, 'Baraka', 'baraka.martin65@gmai', 773839776, 'computer', 'dfudgfdgfudfufyud'),
(11, 'Birori', 'birori@gmail.com', 792215744, 'E-commerce', 'hdfgdgfdfgudsgfhdfggf');

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `user_id` int(5) NOT NULL auto_increment,
  `username` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` (`user_id`, `username`, `email`, `password`) VALUES 
(13, 'ahmed', 'gamal@hotmail.com', '112e9d677c7483747f216a1470bed734'),
(11, 'sex', 'sex@gmail.com', '3c3662bcb661d6de679c636744c66b62'),
(12, 'slau coding', 'slau_coding@gmail.com', 'eb62f6b9306db575c2d596b1279627a4'),
(10, 'mouzamil', 'mouza@gmail.com', '6074c6aa3488f3c2dddff2a7ca821aab'),
(14, 'ceaser', 'ceaser@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(15, 'birori', 'birori@gmail.com', 'cf79ae6addba60ad018347359bd144d2'),
(16, 'Baraka', 'baraka@gmail.com', 'd79c8788088c2193f0244d8f1f36d2db'),
(17, 'viola', 'viola@gmail.com', 'e9510081ac30ffa83f10b68cde1cac07'),
(18, 'juba4', 'juba24@gmail.com', 'e61e7de603852182385da5e907b4b232'),
(19, 'oleyo24', 'oleyo24@gmail.com', '02c425157ecd32f259548b33402ff6d3'),
(20, 'ceaser45', 'ceaser45@gmail.com', '6074c6aa3488f3c2dddff2a7ca821aab'),
(21, 'birori22', 'birori22@gmail.com', '65ba841e01d6db7733e90a5b7f9e6f80'),
(22, 'cease', 'cease99@gmail.com', '11ddbaf3386aea1f2974eee984542152'),
(23, 'simon', 'simon88@githup.com', '6313f91ea9f6fe72eabe153f1a6f6172'),
(24, 'ahmedx', 'ahmedx@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(25, 'ceaser99', 'ceaser99@gmail.com', '11ddbaf3386aea1f2974eee984542152'),
(26, 'simon55', 'simon55@gmail.com', 'c1876da42beb269a906eef38b3ad00fd'),
(27, 'birori66', 'birori66@gmail.com', 'b30bd351371c686298d32281b337e8e9'),
(28, 'simon77', 'simon77@gmail.com', '29a2b2e1849474d94d12051309c7b4d7');
